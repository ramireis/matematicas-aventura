"""Patch Android-only web assets and native TextToSpeech bridge, without touching Windows."""
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
html = root / 'www/index.html'
s = html.read_text(encoding='utf-8')
needle = 'function speak(t){'
assert s.count(needle) == 1, 'Speech function changed: refusing unsafe patch'
s = s.replace(needle, '''function speak(t){
  // Android TextToSpeech: independent of Microsoft Edge and browser voices.
  if(window.AndroidSpeech){
    const msg=String(t);
    $('feedback').setAttribute('aria-label',msg);
    if(!audioEnabled){window.AndroidSpeech.stop();return;}
    $('voiceStatus').textContent='🔊 Voz de Android · español';
    window.AndroidSpeech.speak(msg);
    return;
  }
''', 1)
gate="if(!speechAvailable){$('voiceStatus').textContent='🔇 Necesitas Microsoft Edge con lector de voz activado.';alert('Para jugar necesitas activar el lector de voz de Windows en Microsoft Edge.');return;}"
assert s.count(gate) == 1, 'Windows/Edge startup gate not found; refusing unsafe patch'
s = s.replace(gate, '', 1)
# The question screen had a SECOND Edge-only gate; without removing it the
# first question cannot load even after the start dialog is fixed.
question_gate="if(!speechAvailable){modal('<h2>🔊 Se necesita audio</h2><p>Abre el juego con Microsoft Edge y activa una voz en español en Windows. La evaluación requiere narración.</p><button onclick=\"closeModal();speak(&quot;Prueba de sonido&quot;)\">🔊 Probar voz</button>');return;}"
assert s.count(question_gate) == 1, 'Question voice gate changed; refusing unsafe patch'
s = s.replace(question_gate, '', 1)
# Android voice must be recognized even when the WebView has no browser TTS.
s = s.replace("let speechAvailable = 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;", "let speechAvailable = !!window.AndroidSpeech || ('speechSynthesis' in window && 'SpeechSynthesisUtterance' in window);", 1)
# Do not call browser speech APIs on Android merely because native speech exists.
s = s.replace("if(!speechAvailable)return null;", "if(!window.speechSynthesis)return null;", 1)
s = s.replace("if(speechAvailable){\n  chooseSpanishVoice();", "if(window.speechSynthesis){\n  chooseSpanishVoice();", 1)

# Keep Android speech independent of the browser; remove the Windows-only UI.
s = s.replace('Prueba Microsoft Edge.', 'Revisa el motor de voz de Android.')
# Make the labyrinth legible: do not shrink/tilt the entire canvas in 3D mode.
s = s.replace('transform:perspective(950px) rotateX(28deg) scale(.88);', 'transform:none;')
s = s.replace('tile*.53;ctx.fillStyle', 'tile*.30;ctx.fillStyle')
# Give the maze more horizontal space, with a compact question panel.
s = s.replace('grid-template-columns:minmax(0,1.1fr) minmax(165px,.9fr)', 'grid-template-columns:minmax(0,1.65fr) minmax(250px,.85fr)')
# Fit shorter landscape displays without clipping content.
s = s.replace('</style></head>', """@media (orientation:landscape) and (max-height:650px){#app{grid-template-rows:40px minmax(0,1fr);padding:3px;gap:3px}header h1{font-size:clamp(14px,2.1vw,24px)}.stats{gap:3px}.pill{padding:3px 6px}.panel{padding:4px}.panel h2{font-size:clamp(14px,1.8vw,22px)}.answers{min-height:0;overflow:auto}.mini{width:90px;height:78px;opacity:.75}.worldfoot{bottom:3px}.controls{display:none!important}}
</style></head>""")
# Do not rely on browser-only fullscreen or speech gates to begin a question.
s = s.replace("$('full').onclick=()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()};", "$('full').onclick=()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.().catch(()=>{});else document.exitFullscreen?.().catch(()=>{})};")

s = s.replace('speechRequest++;window.speechSynthesis.cancel();', 'speechRequest++;if(window.speechSynthesis)window.speechSynthesis.cancel();')
assert 'Para jugar necesitas activar el lector de voz de Windows en Microsoft Edge.' not in s
assert 'Abre el juego con Microsoft Edge' not in s
assert 'if(!speechAvailable){modal(' not in s
html.write_text(s, encoding='utf-8')

java = root / 'android/app/src/main/java/ec/edu/edufusion/lumi/MainActivity.java'
assert java.is_file(), 'Capacitor Android project missing'
java.write_text('''package ec.edu.edufusion.lumi;

import android.os.Bundle;
import android.content.pm.ActivityInfo;
import android.view.WindowManager;
import android.media.AudioManager;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private TextToSpeech voice;
    private boolean ready = false;
    private String pending;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getBridge().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface public void speak(String text) {
                runOnUiThread(() -> say(text));
            }
            @JavascriptInterface public void stop() {
                runOnUiThread(() -> { pending = null; if (voice != null) voice.stop(); });
            }
        }, "AndroidSpeech");
        voice = new TextToSpeech(getApplicationContext(), status -> runOnUiThread(() -> {
            if (status != TextToSpeech.SUCCESS || voice == null) {
                Log.e("LumiVoice", "Android TextToSpeech initialization failed: " + status);
                return;
            }
            int result = voice.setLanguage(Locale.forLanguageTag("es-MX"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                result = voice.setLanguage(new Locale("es"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) return;
            voice.setSpeechRate(0.88f);
            voice.setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build());
            voice.setPitch(1.04f);
            ready = true;
            if (pending != null) { String text = pending; pending = null; say(text); }
        }));
    }

    private void say(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (!ready || voice == null) { pending = text; return; }
        voice.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lumi-voice");
    }

    @Override public void onDestroy() {
        if (voice != null) { voice.stop(); voice.shutdown(); voice = null; }
        super.onDestroy();
    }
}
''', encoding='utf-8')

# Capacitor copies www into android assets during `cap add android`, BEFORE this script runs.
# Update the actual packaged file too; otherwise the APK still contains the Edge dialog.
packaged = root / 'android/app/src/main/assets/public/index.html'
assert packaged.is_file(), 'Capacitor packaged index.html missing'
shutil.copyfile(html, packaged)
assert 'Para jugar necesitas activar el lector de voz de Windows en Microsoft Edge.' not in packaged.read_text(encoding='utf-8')
assert 'window.AndroidSpeech.speak(msg)' in packaged.read_text(encoding='utf-8')
assert 'if(!soundOn)' not in packaged.read_text(encoding='utf-8')
assert 'SCREEN_ORIENTATION_SENSOR_LANDSCAPE' in java.read_text(encoding='utf-8')
assert 'Abre el juego con Microsoft Edge' not in packaged.read_text(encoding='utf-8')
print('Verified Android APK assets: native TTS present and Edge startup block absent')
