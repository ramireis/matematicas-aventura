extends Node3D
# Base Godot 4: mallas 3D procedurales jugables. No son modelos GLB con rig ni PBR 4K.
const NAMES = ["Básico", "Estudiante", "Deportista", "Minero", "Científico", "Pirata", "Robot", "Jefe", "Cono", "Cubo", "Globo", "Impulso", "Escudo", "Perro", "Mago", "Explosivo"]
const TITLES = ["Poliedros y cuerpos", "Masa y capacidad", "Proporcionalidad", "Porcentajes", "Áreas y círculo", "Estadística"]
var questions: Array = []
var used: Dictionary = {}
var island := 1
var stars := 0
var total_earned := 0
var practices := 0
var passed := [false, false, false, false, false, false]
var evaluating := false
var exam_n := 0
var exam_hits := 0
var question: Dictionary = {}
var zombie_index := 0
var zombie: Node3D
var hero: Node3D
var legs: Array = []
var arm: Node3D
var projectile: MeshInstance3D
var zombie_x := 7.0
var walking := true
var shooting := false
var shot_t := 0.0
var elapsed := 0.0
var panel: PanelContainer
var title_label: Label
var prompt_label: Label
var info_label: Label
var feedback_label: Label
var buttons: Array[Button] = []
var next_button: Button
var exam_button: Button
var sound := false

func _ready() -> void:
 var raw = FileAccess.get_file_as_string("res://data/banco_400.json")
 var parsed = JSON.parse_string(raw)
 if parsed is Array: questions = parsed
 _build_world()
 _build_ui()
 _load_progress()
 _spawn_zombie()
 _next_question()

func material(color: Color) -> StandardMaterial3D:
 var m = StandardMaterial3D.new()
 m.albedo_color = color
 m.roughness = 0.8
 return m

func part(parent: Node3D, shape: String, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
 var mesh_node = MeshInstance3D.new()
 var mesh: PrimitiveMesh
 if shape == "sphere": mesh = SphereMesh.new()
 elif shape == "cylinder": mesh = CylinderMesh.new()
 else: mesh = BoxMesh.new()
 if mesh is SphereMesh: mesh.radius = 0.5; mesh.height = 1.0
 if mesh is CylinderMesh: mesh.top_radius = 0.5; mesh.bottom_radius = 0.5; mesh.height = 1.0
 if mesh is BoxMesh: mesh.size = Vector3.ONE
 mesh_node.mesh = mesh
 mesh_node.scale = size
 mesh_node.position = pos
 mesh_node.material_override = material(color)
 parent.add_child(mesh_node)
 return mesh_node

func _build_world() -> void:
 var env = WorldEnvironment.new()
 var e = Environment.new()
 e.background_mode = Environment.BG_COLOR
 e.background_color = Color("102139")
 e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 e.ambient_light_color = Color("9fbcd4")
 e.ambient_light_energy = 0.7
 env.environment = e
 add_child(env)
 var light = DirectionalLight3D.new()
 light.rotation_degrees = Vector3(-50, -30, 0)
 light.light_energy = 1.7
 add_child(light)
 var camera = Camera3D.new()
 camera.position = Vector3(0, 7.5, 17)
 camera.rotation_degrees = Vector3(-23, 0, 0)
 camera.current = true
 add_child(camera)
 part(self, "box", Vector3(23, 0.3, 8), Vector3(0, -0.2, 0), Color("326e44"))
 for i in range(10):
  part(self, "box", Vector3(0.025, 0.015, 8), Vector3(-10.35 + i * 2.3, -0.03, 0), Color("6e9d60"))
 for j in range(6):
  part(self, "box", Vector3(23, 0.015, 0.025), Vector3(0, -0.03, -4 + j * 1.6), Color("6e9d60"))
 part(self, "box", Vector3(18, 4, 0.3), Vector3(0, 2.1, -5), Color("455875"))
 part(self, "box", Vector3(6, 2, 0.12), Vector3(0, 2.3, -4.8), Color("163b39"))
 hero = Node3D.new()
 hero.position = Vector3(-7, 0, 0)
 add_child(hero)
 part(hero, "cylinder", Vector3(0.7, 1.4, 0.6), Vector3(0, 1.35, 0), Color("38683a"))
 part(hero, "sphere", Vector3(0.9, 0.95, 0.85), Vector3(0, 2.45, 0), Color("d9a077"))
 part(hero, "box", Vector3(0.95, 0.17, 0.8), Vector3(0, 2.77, 0), Color("d32935"))
 for side in [-1, 1]:
  part(hero, "cylinder", Vector3(0.24, 1.1, 0.25), Vector3(side * 0.23, 0.47, 0), Color("263b38"))
  part(hero, "box", Vector3(0.33, 0.24, 0.52), Vector3(side * 0.23, 0.08, 0.12), Color("272c31"))
  part(hero, "cylinder", Vector3(0.2, 0.95, 0.2), Vector3(side * 0.54, 1.45, 0), Color("c68d67"))
 # Lanzalápices orientado hacia +X.
 part(hero, "box", Vector3(1.65, 0.28, 0.36), Vector3(0.95, 1.7, 0), Color("e9b62d"))
 part(hero, "cylinder", Vector3(0.18, 0.25, 0.18), Vector3(1.78, 1.7, 0), Color("33353c"))
 for k in range(3):
  part(hero, "box", Vector3(0.24, 0.3, 0.08), Vector3(-0.42 + k * 0.4, 1.65, 0.35), Color("374e57"))

func _make_zombie() -> Node3D:
 var root = Node3D.new()
 add_child(root)
 var kind = zombie_index % NAMES.size()
 zombie_index += 1
 var skin = Color("88ae77")
 var cloth = [Color("775c59"), Color("405579"), Color("2764a1"), Color("a88b41"), Color("e0e3df"), Color("593d51"), Color("777f91"), Color("6c4384")][kind % 8]
 if kind == 6: skin = Color("808e9d")
 part(root, "cylinder", Vector3(0.85, 1.4, 0.7), Vector3(0, 1.36, 0), cloth)
 part(root, "sphere", Vector3(1.0, 1.04, 0.94), Vector3(0, 2.42, 0), skin)
 part(root, "sphere", Vector3(0.13, 0.14, 0.13), Vector3(-0.21, 2.53, 0.47), Color("e92f36"))
 part(root, "sphere", Vector3(0.13, 0.14, 0.13), Vector3(0.21, 2.53, 0.47), Color("e92f36"))
 legs.clear()
 for side in [-1, 1]:
  var pivot = Node3D.new()
  pivot.position = Vector3(side * 0.23, 0.76, 0)
  root.add_child(pivot)
  part(pivot, "cylinder", Vector3(0.27, 0.94, 0.29), Vector3(0, -0.44, 0), cloth.darkened(0.28))
  part(pivot, "box", Vector3(0.36, 0.22, 0.6), Vector3(0, -0.85, 0.16), Color("414043"))
  legs.append(pivot)
  var shoulder = Node3D.new()
  shoulder.position = Vector3(side * 0.56, 1.85, 0)
  root.add_child(shoulder)
  part(shoulder, "cylinder", Vector3(0.22, 1.05, 0.23), Vector3(side * 0.13, -0.4, 0.13), skin)
  shoulder.rotation.z = side * 0.4
 if kind == 0 or kind == 11:
  part(root, "box", Vector3(1.0, 0.18, 0.9), Vector3(0, 2.95, 0), Color("bf292b"))
 if kind == 1: part(root, "box", Vector3(0.8, 0.9, 0.28), Vector3(0, 1.45, -0.5), Color("9a6640"))
 if kind == 3: part(root, "cylinder", Vector3(1.0, 0.25, 1.0), Vector3(0, 2.95, 0), Color("e7bf2c"))
 if kind == 4: part(root, "sphere", Vector3(1.1, 0.28, 1.0), Vector3(0, 2.97, 0), Color("e7e8e4"))
 if kind == 5: part(root, "box", Vector3(1.3, 0.22, 0.95), Vector3(0, 3.0, 0), Color("30303d"))
 if kind == 7: part(root, "cylinder", Vector3(0.8, 0.5, 0.8), Vector3(0, 3.08, 0), Color("d6ad37"))
 if kind == 8: part(root, "cylinder", Vector3(0.75, 0.85, 0.75), Vector3(0, 3.08, 0), Color("ef8527"))
 if kind == 9: part(root, "cylinder", Vector3(0.82, 0.68, 0.82), Vector3(0, 3.03, 0), Color("8d969e"))
 if kind == 12: part(root, "box", Vector3(0.2, 1.5, 1.2), Vector3(-0.65, 1.4, 0), Color("8c663e"))
 if kind == 14: part(root, "cylinder", Vector3(0.9, 0.75, 0.9), Vector3(0, 3.13, 0), Color("653d87"))
 if kind == 15: part(root, "cylinder", Vector3(0.7, 0.85, 0.7), Vector3(0, 1.3, -0.55), Color("8d573a"))
 root.rotation.y = -0.25
 return root

func _spawn_zombie() -> void:
 if is_instance_valid(zombie): zombie.queue_free()
 zombie = _make_zombie()
 zombie_x = 7.0
 zombie.position = Vector3(zombie_x, 0, 0)
 walking = true
 shooting = false

func _process(delta: float) -> void:
 elapsed += delta
 if is_instance_valid(zombie) and walking:
  zombie_x = max(-5.8, zombie_x - delta * 0.38)
  zombie.position.x = zombie_x
  zombie.rotation.z = sin(elapsed * 3.0) * 0.055
  if legs.size() == 2:
   legs[0].rotation.z = 0.19 + sin(elapsed * 3.0) * 0.22
   legs[1].rotation.z = -0.22 + sin(elapsed * 3.0 - 1.8) * 0.14
  if zombie_x <= -5.8:
   walking = false
   feedback_label.text = "¡El zombi alcanzó al defensor! Responde para defenderte."
 if shooting and is_instance_valid(projectile):
  shot_t += delta
  projectile.position.x = -5.2 + shot_t * 22.0
  if projectile.position.x >= zombie_x:
   projectile.queue_free()
   shooting = false
   if is_instance_valid(zombie): zombie.rotation.z = -1.3; zombie.position.y = -0.5
   feedback_label.text += "  ¡Impacto!"

func _build_ui() -> void:
 var layer = CanvasLayer.new()
 add_child(layer)
 var outer = Control.new()
 outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 layer.add_child(outer)
 title_label = Label.new()
 title_label.position = Vector2(22, 8)
 title_label.add_theme_font_size_override("font_size", 25)
 outer.add_child(title_label)
 info_label = Label.new()
 info_label.position = Vector2(24, 50)
 outer.add_child(info_label)
 panel = PanelContainer.new()
 panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
 panel.offset_top = -280
 panel.offset_bottom = 0
 outer.add_child(panel)
 var stack = VBoxContainer.new()
 panel.add_child(stack)
 prompt_label = Label.new()
 prompt_label.add_theme_font_size_override("font_size", 23)
 prompt_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 stack.add_child(prompt_label)
 var grid = GridContainer.new()
 grid.columns = 2
 stack.add_child(grid)
 for i in range(4):
  var b = Button.new()
  b.custom_minimum_size = Vector2(400, 42)
  b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  b.pressed.connect(_answer.bind(i))
  grid.add_child(b)
  buttons.append(b)
 feedback_label = Label.new()
 feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 stack.add_child(feedback_label)
 var actions = HBoxContainer.new()
 stack.add_child(actions)
 next_button = Button.new()
 next_button.text = "Siguiente pregunta"
 next_button.pressed.connect(_next_question)
 actions.add_child(next_button)
 exam_button = Button.new()
 exam_button.text = "Evaluación"
 exam_button.pressed.connect(_start_exam)
 actions.add_child(exam_button)
 var center = Button.new()
 center.text = "Centrar ventana"
 center.pressed.connect(func(): DisplayServer.window_set_position((DisplayServer.screen_get_size() - DisplayServer.window_get_size()) / 2))
 actions.add_child(center)
 var minb = Button.new()
 minb.text = "Minimizar"
 minb.pressed.connect(func(): DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MINIMIZED))
 actions.add_child(minb)
 var maxb = Button.new()
 maxb.text = "Maximizar / restaurar"
 maxb.pressed.connect(func(): DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_MAXIMIZED else DisplayServer.WINDOW_MODE_MAXIMIZED))
 actions.add_child(maxb)
 var close = Button.new()
 close.text = "Cerrar"
 close.pressed.connect(func(): get_tree().quit())
 actions.add_child(close)

func _pool() -> Array:
 var p: Array = []
 for q in questions:
  if int(q.get("island", 0)) == island and not used.has(str(q.get("id", ""))): p.append(q)
 return p

func _next_question() -> void:
 if evaluating and exam_n >= 10:
  _finish_exam()
  return
 if not evaluating and practices >= 10 and stars >= 60 and not passed[island - 1]:
  prompt_label.text = "Ya tienes 10 prácticas y 60 estrellas. Inicia la evaluación."
  for b in buttons: b.hide()
  next_button.hide()
  exam_button.show()
  _refresh()
  return
 if not evaluating and passed[island - 1]:
  if island < 6:
   island += 1; practices = 0; stars = 0
   feedback_label.text = "Nueva isla: " + TITLES[island - 1]
   _spawn_zombie()
  elif total_earned > 550:
   prompt_label.text = "Mundo escondido desbloqueado. Evaluación lógica y certificado: pendientes."
   for b in buttons: b.hide()
   next_button.hide()
   return
 var pool = _pool()
 if pool.is_empty():
  prompt_label.text = "Banco agotado. No se repetirán preguntas. Amplía el banco."
  for b in buttons: b.hide()
  next_button.hide()
  exam_button.hide()
  return
 # Orden de dificultad: primeras 4 reconocimiento, 4 siguientes procedimiento, últimas aplicación.
 var stage = 1 if practices < 4 else (2 if practices < 8 else 3)
 var selected: Array = []
 for q in pool:
  var text = str(q.get("prompt", "")).to_lower()
  var level = 3 if ("problema" in text or "interpreta" in text or "factura" in text or "justifica" in text) else (1 if ("qué" in text or "cuál" in text or "identifica" in text or "reconoce" in text) else 2)
  if level == stage: selected.append(q)
 if selected.is_empty(): selected = pool
 question = selected.pick_random()
 used[str(question.get("id", ""))] = true
 _save_progress()
 prompt_label.text = ("EVALUACIÓN %d/10: " % (exam_n + 1) if evaluating else "PRÁCTICA %d: " % (practices + 1)) + str(question.get("prompt", ""))
 var opts: Array = question.get("options", []).duplicate()
 opts.shuffle()
 for i in range(4):
  buttons[i].text = "ABCD"[i] + ". " + str(opts[i])
  buttons[i].set_meta("value", str(opts[i]))
  buttons[i].disabled = false
  buttons[i].show()
 feedback_label.text = "Destreza: " + str(question.get("skill", "")) + " · Indicador: " + str(question.get("indicator", ""))
 next_button.hide()
 exam_button.hide()
 _refresh()

func _answer(index: int) -> void:
 if question.is_empty() or buttons[index].disabled: return
 var correct = str(buttons[index].get_meta("value")) == str(question.get("answer", ""))
 for b in buttons: b.disabled = true
 if evaluating:
  exam_n += 1
  if correct: exam_hits += 1
 else:
  practices += 1
  if correct: stars += 10; total_earned += 10
  else: stars = max(0, stars - 2)
 if correct:
  walking = false
  projectile = part(self, "cylinder", Vector3(0.12, 0.75, 0.12), Vector3(-5.2, 1.7, 0), Color("f4c52d"))
  projectile.rotation.z = PI / 2
  shot_t = 0.0
  shooting = true
  feedback_label.text = "¡Correcto! Disparo activado. " + str(question.get("explanation", ""))
 else:
  walking = true
  feedback_label.text = "Incorrecto: -2 estrellas en práctica. El zombi sigue avanzando. Respuesta: " + str(question.get("answer", "")) + ". " + str(question.get("explanation", ""))
 _save_progress()
 next_button.show()
 _refresh()
 if correct: get_tree().create_timer(1.0).timeout.connect(_spawn_zombie)

func _start_exam() -> void:
 if practices < 10 or stars < 60: return
 if _pool().size() < 10:
  feedback_label.text = "No quedan 10 preguntas inéditas para la evaluación."
  return
 evaluating = true; exam_n = 0; exam_hits = 0
 _next_question()

func _finish_exam() -> void:
 evaluating = false
 passed[island - 1] = exam_hits >= 7
 prompt_label.text = "Evaluación: %d/10. %s" % [exam_hits, "APROBADO" if exam_hits >= 7 else "Debes volver a intentarlo"]
 feedback_label.text = "Se utilizarán preguntas nuevas en el siguiente intento."
 for b in buttons: b.hide()
 next_button.show()
 exam_button.hide()
 _save_progress()

func _refresh() -> void:
 title_label.text = "MATEMÁTICAS VS. ZOMBIS 3D · ISLA %d/6 · %s" % [island, TITLES[island - 1]]
 info_label.text = "Prácticas: %d/10 · Estrellas isla: %d/60 · Acumuladas: %d · Zombi: %s" % [practices, stars, total_earned, NAMES[(zombie_index - 1) % NAMES.size()]]

func _save_progress() -> void:
 var f = FileAccess.open("user://progreso.json", FileAccess.WRITE)
 if f: f.store_string(JSON.stringify({"used": used, "island": island, "stars": stars, "total": total_earned, "practices": practices, "passed": passed}))

func _load_progress() -> void:
 if not FileAccess.file_exists("user://progreso.json"): return
 var data = JSON.parse_string(FileAccess.get_file_as_string("user://progreso.json"))
 if not data is Dictionary: return
 used = data.get("used", {})
 island = clampi(int(data.get("island", 1)), 1, 6)
 stars = int(data.get("stars", 0))
 total_earned = int(data.get("total", 0))
 practices = int(data.get("practices", 0))
 var saved = data.get("passed", [])
 if saved is Array and saved.size() == 6: passed = saved
