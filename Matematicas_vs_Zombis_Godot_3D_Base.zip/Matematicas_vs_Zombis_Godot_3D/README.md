# Matemáticas vs. Zombis — migración real a Godot 4 (base de desarrollo)

Este proyecto **sí usa un motor 3D** y mallas tridimensionales procedurales para el héroe y 16 variantes de zombis. Los modelos son prototipos geométricos construidos en tiempo de ejecución: **no son** los modelos de alta fidelidad, GLB, esqueleto, rig, texturas 4K ni los diseños exactos de los prompts. No incluye DLL personalizada ni EXE precompilado.

## Ejecutar
Instalar Godot 4.2 o posterior, importar `project.godot` y ejecutar F6/F5. La cámara 3D, escenario, héroe y zombis son parte del juego; no son una carátula. Juego sin internet y sin modificar Wi-Fi ni configuraciones del sistema. La ventana es redimensionable y usa botones de minimizar, maximizar, centrar y cerrar.

## Mecánica implementada
- 16 variantes de zombis generados como mallas 3D (ropa y accesorios simplificados), aparecen uno a uno desde la derecha; marcha lenta con rotación alterna de piernas y arrastre aproximado.
- El héroe se sitúa a la izquierda, con banda roja, chaleco verde, calculadoras y lanzalápices geométrico.
- Solo una respuesta correcta genera proyectil. Respuesta incorrecta: -2 estrellas en práctica y zombi sigue avanzando.
- Banco heredado de 400 preguntas para 7.º EGB. Se registra ID usado localmente para no repetirlo; cuando se agota, se detiene. Alternativas aleatorias.
- Mínimo 10 prácticas y 60 estrellas para examen de 10 reactivos; aprobar con 7/10 para siguiente isla.
- Seis islas y progreso local.

## Pendiente y limitaciones
- El banco de 400 preguntas se heredó **sin auditoría pedagógica completa**. Las destrezas/indicadores constan en cada registro, pero DUA/ERCA/ACC/Marzano necesitan diseño y validación por actividad; no se declara cumplimiento integral.
- No hay modelos 3D artísticos `.glb` / `.fbx`, rig ni animaciones de estudio. Los 16 personajes son prototipos 3D geométricos. Escenario escolar es geometría 3D sencilla; laboratorio y nocturno artísticos pendientes.
- Mundo escondido: solo mensaje de desbloqueo, sin examen lógico ni certificado todavía.
- 3.º y 8.º no tienen bancos propios ni están implementados.
- No se ha ejecutado una prueba de Godot en este entorno (Godot no instalado). Es base editable que requiere abrir y depurar en el motor.
- Las evaluaciones consumen preguntas inéditas; con un banco finito no puede haber repetición ilimitada sin ampliar contenido.

## Compilar EXE en Windows
En Godot: Editor > Manage Export Templates (instalar plantilla de la versión instalada) > Project > Export > Add Windows Desktop > Export Project. Alternativamente, usar el flujo de GitHub Actions adjunto y descargar artifact; la compilación no ha sido verificada aquí.
