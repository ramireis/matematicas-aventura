const { app, BrowserWindow } = require('electron');
const path = require('path');
app.whenReady().then(() => { const win = new BrowserWindow({ width: 1366, height: 820, minWidth: 960, minHeight: 620, autoHideMenuBar: true, webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } }); win.loadFile(path.join(__dirname, 'index.html')); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
