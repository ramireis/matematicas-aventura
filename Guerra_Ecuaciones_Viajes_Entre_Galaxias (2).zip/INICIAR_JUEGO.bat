@echo off
start "" "%~dp0www\index.html"
