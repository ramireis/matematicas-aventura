"use strict";
const {app,BrowserWindow,ipcMain,screen}=require('electron');
const path=require('path');
let win;
function createWindow(){
 const area=screen.getPrimaryDisplay().workArea;
 win=new BrowserWindow({width:Math.min(1280,area.width),height:Math.min(820,area.height),minWidth:900,minHeight:620,center:true,frame:false,show:false,autoHideMenuBar:true,backgroundColor:'#071421',webPreferences:{preload:path.join(__dirname,'preload.js'),nodeIntegration:false,contextIsolation:true,sandbox:true}});
 win.loadFile(path.join(__dirname,'index.html'));
 win.once('ready-to-show',()=>win.show());
 win.on('maximize',()=>win.webContents.send('window-state',true));
 win.on('unmaximize',()=>win.webContents.send('window-state',false));
}
ipcMain.on('window-control',(event,action)=>{if(!win||event.sender!==win.webContents)return;switch(action){case 'minimize':win.minimize();break;case 'maximize':win.isMaximized()?win.unmaximize():win.maximize();break;case 'center':if(win.isMaximized())win.unmaximize();win.center();break;case 'close':win.close();break;}});
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
