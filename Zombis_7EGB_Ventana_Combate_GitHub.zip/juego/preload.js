"use strict";
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('gameWindow',{control:action=>{if(['minimize','maximize','center','close'].includes(action))ipcRenderer.send('window-control',action)},onState:callback=>ipcRenderer.on('window-state',(_event,maximized)=>callback(maximized))});
