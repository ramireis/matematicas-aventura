# Matemáticas vs. Zombis — reconstrucción desde cero, 7.º EGB (prototipo v0.1)

Abrir `index.html` en Chrome o Edge. No requiere conexión a internet. Mantener juntos `index.html`, `game.js` y `bank.js`. `generate.py` produce `banco_400.json` y `bank.js` con Python 3.

## Implementado
- 6 islas secuenciales; cada isla tiene contenido propio y una introducción.
- Actividad correcta +10 estrellas; incorrecta −2 estrellas (sin saldo negativo). Mínimo 60 para rendir evaluación.
- Evaluación obligatoria de 10 preguntas, aprobado >=7/10. Preguntas de evaluación no se repiten entre intentos de este perfil local; se detiene si quedan menos de 10 inéditas en la isla. Opciones mezcladas cada vez.
- Banco de 400 reactivos únicos en texto: 67/67/67/67/66/66 por isla, guardado en JSON. Son reactivos generados y **requieren revisión pedagógica**, no provienen del diagnóstico.
- Progreso y preguntas evaluadas guardados en localStorage. Tras aprobar todas las islas y superar 550 estrellas acumuladas, se habilita certificado imprimible. Práctica adicional permite acumular estrellas sin regalar puntos.

## Pendiente, NO implementado
- 3.º y 8.º EGB, examen diagnóstico no adjuntado, actividades manipulativas diferenciadas, 3D real, 16 modelos 3D, animaciones, QR, control docente, evaluación de razonamiento del mundo oculto, certificados con verificación de identidad, instaladores EXE/APK.
- Se usa emoji provisional para personajes, sin reutilizar assets de franquicias. La imagen de referencia generada no es un modelo 3D ni está incorporada al juego.
- Se recomienda que el docente revise respuestas, dificultad y precisión de los 400 reactivos antes de distribuir a estudiantes. Este prototipo es una base técnica, no un producto final validado.

## Nota de seguridad
El progreso es local y puede modificarse con herramientas del navegador: no usar como sistema de calificación oficial ni certificado verificable. Para distribuir en 150 dispositivos, implementar almacenamiento y exportación seguros y pruebas de usabilidad.
