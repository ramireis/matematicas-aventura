# Ajustes de ventana y combate
- Ventana Electron sin marco, con botones propios minimizar, maximizar/restaurar, centrar y cerrar.
- Interfaz compacta sin barras de desplazamiento; tamaño mínimo de ventana 900 × 620. En monitores menores, Windows puede limitar el espacio disponible; no se garantiza legibilidad en resoluciones inferiores.
- Modo conectado/sin internet es una preferencia de la aplicación, NO modifica adaptadores, Wi-Fi, firewall ni configuración de Windows. El prototipo no dispone de sincronización en línea: ambos modos funcionan localmente.
- Zombi aparece a la derecha y avanza a la izquierda; acierto dispara y lo elimina visualmente; error lo detiene para mostrar retroalimentación. La animación es 2D con emojis, NO modelos 3D.
- Compilar con el flujo GitHub Actions incluido. El archivo EXE no está incluido en este ZIP.
