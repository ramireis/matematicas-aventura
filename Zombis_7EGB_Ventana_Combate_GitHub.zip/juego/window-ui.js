"use strict";
(function(){
 const byId=id=>document.getElementById(id);
 for(const [id,action] of [['winMin','minimize'],['winMax','maximize'],['winCenter','center'],['winClose','close']])byId(id).addEventListener('click',()=>{if(window.gameWindow)window.gameWindow.control(action);else if(action==='close')window.close();else if(action==='maximize')document.documentElement.requestFullscreen?.();else if(action==='center')document.exitFullscreen?.()});
 window.gameWindow?.onState(max=>byId('winMax').textContent=max?'❐':'□');
 let online=false;
 const button=byId('connection');
 function render(){button.textContent=online?'Modo conectado':'Modo sin internet';button.classList.toggle('offline',!online);button.title='Solo cambia el modo del juego. No activa ni desactiva la red del equipo.'}
 button.onclick=()=>{online=!online;render();byId('combatStatus').textContent=online?'Modo conectado: juego local; no se transmiten datos.':'Modo sin internet: juego local, sin cambios en la red de Windows.'};render();
 // No se realizan peticiones de red: el juego y sus preguntas son locales.
})();
